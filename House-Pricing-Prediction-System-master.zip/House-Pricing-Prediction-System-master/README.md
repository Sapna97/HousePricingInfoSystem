# House-Pricing-Prediction-System
This project is predicts the prices of house according to the data of Bangalore (2018).
It is a web app created using following:
## Front end :
HTML,
CSS,
Bootstrap,
JavaScript with jQuery

## Back end:
Django

## Machine Learning (python)
NumPy,
Pandas,
Matplotlib,
StandardScaler,
GradientBoostRegressor,
Pickle,
Joblib
