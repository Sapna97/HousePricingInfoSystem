from django.contrib import admin
from broker.models import *

admin.site.register(Broker)
admin.site.register(Adv)
